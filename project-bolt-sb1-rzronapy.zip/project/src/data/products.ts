export const products = [
  {
    id: 1,
    name: "Montre Connectée Premium",
    price: 129.99,
    description: "Montre connectée dernière génération avec suivi d'activité 24/7, notifications et 30 jours d'autonomie",
    image: "https://images.unsplash.com/photo-1546868871-7041f2a55e12?w=800",
    category: "Electronics",
    stock: 8
  },
  {
    id: 2,
    name: "Écouteurs Sans Fil Pro",
    price: 79.99,
    description: "Écouteurs bluetooth avec réduction de bruit active, qualité studio et étanchéité IPX7",
    image: "https://images.unsplash.com/photo-1572569511254-d8f925fe2cbb?w=800",
    category: "Electronics",
    stock: 15
  },
  {
    id: 3,
    name: "Sac à Dos Voyage Smart",
    price: 89.99,
    description: "Sac à dos imperméable avec port USB, compartiment ordinateur et système anti-vol",
    image: "https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=800",
    category: "Accessories",
    stock: 5
  },
  {
    id: 4,
    name: "Lampe LED Design",
    price: 49.99,
    description: "Lampe de bureau moderne avec contrôle tactile, 5 modes d'éclairage et port de charge USB",
    image: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=800",
    category: "Home",
    stock: 12
  }
];