import React from 'react';
import { Timer, Truck, Shield } from 'lucide-react';

export const Hero: React.FC = () => {
  return (
    <div className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-12 mb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Des Produits Innovants à Prix Imbattables
          </h1>
          <p className="text-xl text-indigo-100 max-w-2xl mx-auto">
            Découvrez notre sélection de produits tendance avec une garantie satisfaction à 100%
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-8">
          <div className="flex items-center justify-center space-x-4 bg-white/10 rounded-lg p-4">
            <Timer className="h-8 w-8" />
            <div>
              <h3 className="font-semibold">Livraison Express</h3>
              <p className="text-sm text-indigo-100">Sous 5-7 jours ouvrés</p>
            </div>
          </div>
          <div className="flex items-center justify-center space-x-4 bg-white/10 rounded-lg p-4">
            <Shield className="h-8 w-8" />
            <div>
              <h3 className="font-semibold">Garantie 30 Jours</h3>
              <p className="text-sm text-indigo-100">Satisfait ou remboursé</p>
            </div>
          </div>
          <div className="flex items-center justify-center space-x-4 bg-white/10 rounded-lg p-4">
            <Truck className="h-8 w-8" />
            <div>
              <h3 className="font-semibold">Livraison Gratuite</h3>
              <p className="text-sm text-indigo-100">Dès 50€ d'achat</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};