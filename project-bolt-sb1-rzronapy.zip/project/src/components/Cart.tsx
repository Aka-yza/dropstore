import React from 'react';
import { useCart } from '../context/CartContext';
import { Minus, Plus, Trash2, CreditCard, Lock } from 'lucide-react';

export const Cart: React.FC = () => {
  const { state, dispatch } = useCart();

  return (
    <div className="bg-white rounded-lg shadow-md p-6 sticky top-4">
      <h2 className="text-2xl font-bold mb-4">Votre Panier</h2>
      {state.items.length === 0 ? (
        <p className="text-gray-500">Votre panier est vide</p>
      ) : (
        <>
          {state.items.map(item => (
            <div key={item.id} className="flex items-center gap-4 py-4 border-b">
              <img
                src={item.image}
                alt={item.name}
                className="w-20 h-20 object-cover rounded"
              />
              <div className="flex-1">
                <h3 className="font-semibold">{item.name}</h3>
                <div className="flex items-center gap-2">
                  <p className="text-indigo-600 font-bold">{item.price.toFixed(2)} €</p>
                  <p className="text-sm text-gray-500 line-through">
                    {(item.price * 1.4).toFixed(2)} €
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() =>
                    dispatch({
                      type: 'UPDATE_QUANTITY',
                      payload: { id: item.id, quantity: Math.max(0, item.quantity - 1) }
                    })
                  }
                  className="p-1 rounded hover:bg-gray-100"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-8 text-center">{item.quantity}</span>
                <button
                  onClick={() =>
                    dispatch({
                      type: 'UPDATE_QUANTITY',
                      payload: { id: item.id, quantity: item.quantity + 1 }
                    })
                  }
                  className="p-1 rounded hover:bg-gray-100"
                >
                  <Plus className="h-4 w-4" />
                </button>
                <button
                  onClick={() => dispatch({ type: 'REMOVE_FROM_CART', payload: item.id })}
                  className="p-1 text-red-500 hover:bg-red-50 rounded"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          ))}
          <div className="mt-6 space-y-4">
            <div className="flex justify-between text-sm">
              <span>Sous-total</span>
              <span>{state.total.toFixed(2)} €</span>
            </div>
            <div className="flex justify-between text-sm">
              <span>Livraison</span>
              <span>{state.total >= 50 ? 'Gratuite' : '4.99 €'}</span>
            </div>
            <div className="border-t pt-4">
              <div className="flex justify-between text-lg font-bold">
                <span>Total</span>
                <span>{(state.total >= 50 ? state.total : state.total + 4.99).toFixed(2)} €</span>
              </div>
            </div>
            <button className="w-full bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition-colors flex items-center justify-center gap-2">
              <Lock className="h-4 w-4" />
              <span>Payer en toute sécurité</span>
            </button>
            <div className="flex items-center justify-center gap-2 mt-4">
              <CreditCard className="h-5 w-5 text-gray-400" />
              <span className="text-sm text-gray-500">Paiement 100% sécurisé</span>
            </div>
          </div>
        </>
      )}
    </div>
  );
};