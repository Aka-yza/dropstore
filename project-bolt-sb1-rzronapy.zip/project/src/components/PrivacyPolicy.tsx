import React from 'react';
import { Shield, Lock, Eye, Database, Cookie, Mail } from 'lucide-react';

export const PrivacyPolicy: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-lg shadow-md p-8">
        <div className="flex items-center gap-3 mb-8">
          <Shield className="h-8 w-8 text-indigo-600" />
          <h1 className="text-3xl font-bold text-gray-900">Politique de Confidentialité</h1>
        </div>

        <div className="prose prose-indigo max-w-none">
          <p className="text-gray-600 mb-8">
            Dernière mise à jour : {new Date().toLocaleDateString()}
          </p>

          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Eye className="h-6 w-6 text-indigo-600" />
              <h2 className="text-xl font-semibold">Collecte des Informations</h2>
            </div>
            <p className="text-gray-700 mb-4">
              Nous collectons les informations que vous nous fournissez directement lorsque vous :
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Créez un compte</li>
              <li>Effectuez un achat</li>
              <li>Vous inscrivez à notre newsletter</li>
              <li>Contactez notre service client</li>
            </ul>
          </section>

          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Database className="h-6 w-6 text-indigo-600" />
              <h2 className="text-xl font-semibold">Utilisation des Données</h2>
            </div>
            <p className="text-gray-700 mb-4">
              Nous utilisons vos informations personnelles pour :
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Traiter vos commandes et paiements</li>
              <li>Vous envoyer des confirmations de commande</li>
              <li>Vous informer sur nos offres spéciales</li>
              <li>Améliorer nos services</li>
              <li>Prévenir la fraude</li>
            </ul>
          </section>

          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Cookie className="h-6 w-6 text-indigo-600" />
              <h2 className="text-xl font-semibold">Cookies et Technologies Similaires</h2>
            </div>
            <p className="text-gray-700 mb-4">
              Nous utilisons des cookies et technologies similaires pour :
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Maintenir votre session</li>
              <li>Mémoriser vos préférences</li>
              <li>Analyser le trafic du site</li>
              <li>Personnaliser votre expérience</li>
            </ul>
          </section>

          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Lock className="h-6 w-6 text-indigo-600" />
              <h2 className="text-xl font-semibold">Protection des Données</h2>
            </div>
            <p className="text-gray-700 mb-4">
              Nous mettons en œuvre des mesures de sécurité appropriées pour protéger vos données :
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Chiffrement SSL/TLS</li>
              <li>Accès restreint aux données personnelles</li>
              <li>Surveillance continue de la sécurité</li>
              <li>Mise à jour régulière de nos systèmes</li>
            </ul>
          </section>

          <section className="mb-8">
            <div className="flex items-center gap-2 mb-4">
              <Mail className="h-6 w-6 text-indigo-600" />
              <h2 className="text-xl font-semibold">Vos Droits</h2>
            </div>
            <p className="text-gray-700 mb-4">
              Conformément au RGPD, vous disposez des droits suivants :
            </p>
            <ul className="list-disc pl-6 text-gray-700 space-y-2">
              <li>Droit d'accès à vos données</li>
              <li>Droit de rectification</li>
              <li>Droit à l'effacement</li>
              <li>Droit à la portabilité</li>
              <li>Droit d'opposition au traitement</li>
            </ul>
          </section>

          <div className="mt-12 p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-600">
              Pour toute question concernant notre politique de confidentialité ou pour exercer vos droits,
              contactez-nous à : <a href="mailto:privacy@dropstore.com" className="text-indigo-600 hover:text-indigo-800">
              privacy@dropstore.com</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};